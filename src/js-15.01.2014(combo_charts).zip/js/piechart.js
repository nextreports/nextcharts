/*
 * Json must contain as mandatory only "data" attribute 
 * 
 * type -> piechart
 * message -> can have two markups #val for value, #percent for percent and #total for total value
 *         -> can contain <br> to split text on more lines
 * title.alignment -> center, left, right
 * 
 * { "type": "pie",  *   
 *   "background" : "white",
 * 	 "data": [[ 16, 66, 24, 30, 80, 52 ]], 
 *   "labels": ["JANUARY","FEBRUARY","MARCH","APRIL","MAY", "JUNE"],     
 *   "color": ["#004CB3","#A04CB3", "#7aa37a", "#f18e9f", "#90e269", "#bc987b"],   
 *   "alpha" : 0.8,  *    
 *   "message" : "Value \: #val",  *    
 *   "title" : {
 *   	"text": "Analiza financiara", 
 *   	"font": {
 *   		"weight": "bold", 
 *   		"size": "16", 
 *   		"family": "sans-serif"
 *   	}, 
 *   	"color": "#000000",
 *      "alignment":"left"
 *   },    
 *   "xData" : {
 *   	"font": {
 *   		"weight": "bold", 
 *   		"size": "16", 
 *   		"family": "sans-serif"
 *   	}, 
 *   	"color": "blue"
 *   },
 *   "tooltipPattern" : {
 *   	"decimals": 2,
 *   	"decimalSeparator" : ".",
 *      "thousandSeparator" : ","
 *   }
 * }
 * 
 */

var pieChart = function(myjson, can, tipCan) {

var obj;
var data;
var labels; 
var globalAlpha;
var background;
var message;
var chartType;
var seriesColor;
var titleSpace = 0;
var realWidth;
var realHeight;
var canvas;  
var c; 
var tipCanvas;
var H = 6;
var line = 20;
var hline = 5;

function drawPie(myjson, can, tipCan) {	
			
	canvas = can;  
	c = canvas.getContext('2d');
	
	obj = myjson;
	chartType = obj.type;
	if (typeof chartType === "undefined") {
	    chartType = "pie";
	}		
					
	background = obj.background;
	if (typeof background === "undefined") {	
		background = "white";
	}			
	
	data = obj.data[0];	
	
	labels = obj.labels; 		
	
	globalAlpha = obj.alpha;
	if (typeof globalAlpha === "undefined") {
        globalAlpha = 0.8;
    }
			
	message = obj.message;
	if (typeof message === "undefined") {		
		message = "#val / #total<br>#percent% of 100%";		
	}
					
	seriesColor = obj.color;
	if (typeof seriesColor === "undefined") {
		seriesColor = distinctHexColors(data.length);
    }    
	// if less colors than data are specified, append more of them
	if (seriesColor.length < data.length) {
		seriesColor = seriesColor.concat(distinctHexColors(data.length-seriesColor.length));
	}
        
	realWidth = canvas.width;
	realHeight = canvas.height;	
							
	tipCanvas = tipCan;	
    
    canvas.addEventListener('mousemove', 
			function(evt) { 
				var hme = Object.create(handleMouseEvent);
				hme.mousePos = getMousePos(canvas, evt);				
				hme.tooltip = getTooltip(hme.mousePos);		
				hme.execute(canvas, tipCanvas, evt); 
			}, 
			false);     
    
    canvas.addEventListener("click", onClick, false);

	drawChart();
}


function animDraw() {      
    if (drawIt(H)) {          		    
        return false;
    }    
    H += 1+(realHeight-titleSpace)/30;    
    window.requestAnimFrame(animDraw);      
}    


// function called repetitive by animation
function drawIt(H) {    		
	
	drawInit();
					
	var stop = drawData(true, false, "");		
	 				
	return stop;
}

// withFill = false means to construct just the path needed for tooltip purposes
function drawData(withFill, withClick, mousePos) {
	var font = c.font;
	    
	//draw data 
	c.lineWidth = 1.0;
	var stop = true;	
	
	var pieData = [];
	var cx = realWidth-2*getMaxLabelWidth()-2*line-20;
	var cy = realHeight-titleSpace-getLabelHeight()-2*line-20;
	var center = [realWidth / 2, (realHeight+titleSpace) / 2];	
	var radius = Math.min(cx, cy) / 2;
	if (radius < 0) {
		radius = 20;
	}
	var total = 0;
	var lastPosition = 0;
	// total up all the data for chart
	for (var i in data) { total += data[i]; }
	
	if (radius < H) {
        H = radius;
    } else {
        stop = false;
    } 
	
	// populate arrays for each slice
	for(var i in data) {
		pieData[i] = [];
		pieData[i]['value'] = data[i];
		var percent = data[i]*100/total;		
		pieData[i]['percent'] = Math.round(percent*100)/100;
		pieData[i]['startAngle'] = 2 * Math.PI * lastPosition;
		pieData[i]['endAngle'] = 2 * Math.PI * (lastPosition + (data[i]/total));
		pieData[i]['labelAngle'] = pieData[i]['startAngle'] + Math.abs(pieData[i]['endAngle']-pieData[i]['startAngle'])/2;
		pieData[i]['middle'] = [center[0]+H*Math.cos(pieData[i]['labelAngle']), center[1]+H*Math.sin(pieData[i]['labelAngle'])];
		lastPosition += data[i]/total;
	}
			    
	for(var i=0; i<data.length; i++) {  	  		 	  	    		   	    	    	    	     
	    
		if (withFill) {
		    var gradient = c.createLinearGradient( 0, 0, realWidth, realHeight );
			gradient.addColorStop( 0, "#ddd" );
			gradient.addColorStop( 1, seriesColor[i] );
	
			// draw slices
			c.beginPath();
			if (pieData.length > 1) {
				c.moveTo(center[0],center[1]);
			}				
			c.arc(center[0],center[1],H,pieData[i]['startAngle'],pieData[i]['endAngle'],false);
			if (pieData.length > 1) {
				c.lineTo(center[0],center[1]);
			}
			c.closePath();
			c.fillStyle = gradient;
			c.fill();			
			c.lineWidth = 1;
			c.strokeStyle = "#fff";
			c.stroke();	  			
		
			// draw Labels	
			if (typeof labels !== "undefined") {
				drawLabels(i, pieData);
			}
			
		} else {
	    		    		    	
	    	var fromCenterX = mousePos.x - center[0];
			var fromCenterY = mousePos.y - center[1];
			var fromCenter = Math.sqrt(Math.pow(Math.abs(fromCenterX), 2) + Math.pow(Math.abs(fromCenterY), 2 ));

			if (fromCenter <= radius) {
				var angle = Math.atan2(fromCenterY, fromCenterX);
				if (angle < 0) angle = 2 * Math.PI + angle; // normalize

				for (var slice in pieData) {
					if (angle >= pieData[slice]['startAngle'] && angle <= pieData[slice]['endAngle']) {
						var tValue = pieData[slice]['value'];						
			    		if (obj.tooltipPattern !== undefined) {
			    			tValue = formatNumber(tValue, obj.tooltipPattern.decimals, obj.tooltipPattern.decimalSeparator, obj.tooltipPattern.thousandSeparator);
			    		}	  
			    		if (withClick) {
			    			return tValue;
			    		} else {
					    	var mes = String(message).replace('#val', tValue);
					    	mes = mes.replace('#total', total);
					    	mes = mes.replace('#percent', pieData[slice]['percent']);
					        canvas.style.cursor = 'pointer';     
					        return mes;
			    		}
					} else {
						canvas.style.cursor = 'default';
					}
				}
			}	
	    					   
	    }
	   
	}   	
		
	if (withFill) {
		return stop;
	} else {
		// empty tooltip message
		return "";
	}
}

function drawLabels(i, pieData) {
	var x = pieData[i]['middle'][0];
	var y = pieData[i]['middle'][1];
	var x1 = x + line*Math.cos(pieData[i]['labelAngle']);
	var y1 = y + line*Math.sin(pieData[i]['labelAngle']);	
	
	c.beginPath();
	c.moveTo(x, y);
	c.lineTo(x1, y1);
	
	var writeFrom = true;	
	if ((pieData[i]['labelAngle'] == Math.PI) || (pieData[i]['labelAngle'] == 2*Math.PI)) {
		// no horizontal line to draw	
		if ((pieData[i]['labelAngle'] == Math.PI) || (pieData.length == 1)) {
			writeFrom = false;
		}
	} else if (pieData[i]['labelAngle'] <= Math.PI/2) {		
		x1 = x1+hline;				
	} else if (pieData[i]['labelAngle'] < Math.PI) {
		x1 = x1-hline;
		writeFrom = false;
	} else if (pieData[i]['labelAngle'] <= 3*Math.PI/2) {
		x1 = x1-hline;
		writeFrom = false;
	} else if (pieData[i]['labelAngle'] < 2*Math.PI) {
		x1 = x1+hline;
	}
	c.lineTo(x1, y1);	
	
	c.strokeStyle = seriesColor[i];
	c.stroke();
	
	c.fillStyle = seriesColor[i];
	var fontHeight = 12;
	if (obj.xData !== undefined) {
		//c.fillStyle = obj.xData.color; 
		var b = " ";
		var xfont = obj.xData.font;
		fontHeight = xfont.size;
		c.font = xfont.weight + b + xfont.size + "px" + b + xfont.family;  
	} else {		
		c.font = "bold 12px sans-serif";
	}	   		
		
	if (writeFrom) {
		c.fillText(labels[i],x1+5, y1 + fontHeight/2);
	} else {
		var size = c.measureText(labels[i]).width+5;
		c.fillText(labels[i],x1-size, y1 + fontHeight/2);
	}
}


function drawInit() {
	
	var font = c.font;
	
	//draw background (clear canvas)
	c.fillStyle = background; 	
	c.fillRect(0,0,realWidth,realHeight);			

	//draw title		
	if (typeof obj.title !== "undefined") {
		var titleColor = obj.title.color;
		if (titleColor === undefined) {
			titleColor = '#000000';
		}
		c.fillStyle = titleColor;
		var b = " ";
		var f = obj.title.font;
		if (f === undefined) {
			f.weight = "bold";
			f.size = 12;
			f.family = "sans-serif";
		}
		c.font = f.weight + b + f.size + "px" + b + f.family;   		
		titleSpace = +20 + +f.size;
		 
		var alignment = obj.title.alignment;
		if (alignment === undefined) {
			alignment = "center";
		}
		var xTitle;
		if (alignment == "left") {
			xTitle = hStep;
		} else if (alignment == "right") {
			xTitle = canvas.width - c.measureText(obj.title.text).width - 10;
		} else {
			// center
			xTitle = canvas.width/2- c.measureText(obj.title.text).width/2;
		}				
		
		c.fillText(obj.title.text, xTitle , 20+titleSpace/2 );    
		c.font = font;   				
	} else {
		titleSpace = 0;
	}    
			
	c.font = font;   
}

function getTooltip(mousePos) {	
	return drawData(false, false, mousePos);	 	  	 
}      

function onClick(evt) {
	var v = drawData(false, true, getMousePos(canvas, evt));
	console.log("click on = " + v);
	return v;
}

function drawChart() {	
    window.requestAnimFrame = (function(){
      return  window.requestAnimationFrame       ||
              window.webkitRequestAnimationFrame ||
              window.mozRequestAnimationFrame    ||
              window.oRequestAnimationFrame      ||
              window.msRequestAnimationFrame     ||
              function(/* function */ callback, /* DOMElement */ element){
                window.setTimeout(callback, 1000/60);
              };
    })();                
            
    window.requestAnimFrame(animDraw); 
}  

function getTitleSpace() {
	var space = 0;
	if (typeof obj.title !== "undefined") {		
		var f = obj.title.font;
		if (f === undefined) {			
			f.size = 12;			
		}		      
		space = +20 + +f.size;  
	} 
	return space;
}

function getLabelHeight() {
	var fontHeight = 12;
	if (obj.xData !== undefined) {		
		fontHeight = obj.xData.font.size;		 
	}
	return fontHeight;
}

function getMaxLabelWidth() {
	if (typeof labels === "undefined") {
		return 0;
	}
	var font = c.font;
	var max = 0;	
	if (obj.xData !== undefined) {		 
		var b = " ";
		var xfont = obj.xData.font;
		fontHeight = xfont.size;
		c.font = xfont.weight + b + xfont.size + "px" + b + xfont.family;  
	} else {		
		c.font = "bold 12px sans-serif";
	}	   					
	for(var i=0; i<labels.length; i++) {   
		var size = c.measureText(labels[i]).width+5;		
		if (size > max) {
			max = size;
		}
	}
	c.font = font;	
	return max;
}


drawPie(myjson, can, tipCan);

};