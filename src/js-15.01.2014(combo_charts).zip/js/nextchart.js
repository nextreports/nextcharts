function nextChart(myjson, can, tipCan) {	
				
	var chartType = myjson.type;
	if (typeof chartType === "undefined") {
	    chartType = "line";
	}		
	
	if (isBar(chartType)) {
		barChart(myjson, can, tipCan);
	} else if (isPie(chartType)) {
		pieChart(myjson, can, tipCan);	
	} else {
		lineChart(myjson, can, tipCan);
	}
	
}	

function isBar(chartType) {
	return (chartType == "bar") || (chartType == "hbar") || (chartType == "stackedbar") || (chartType == "hstackedbar");
}

function isLine(chartType) {
	return (chartType == "line") || (chartType == "area");
}

function isPie(chartType) {
	return (chartType == "pie");
}